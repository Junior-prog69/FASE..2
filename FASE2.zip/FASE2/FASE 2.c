// main.c
#include <stdio.h>
#include "grafo.h"

int main() {
    Grafo* g = lerGrafoDeFicheiro("mapa.txt");

    printf("DFS:\n");
    int vis[100] = {0};
    dfs(g, 0, vis);

    printf("\nBFS:\n");
    bfs(g, 0);

    printf("\nCaminhos entre vértices 0 e 3:\n");
    int caminho[100];
    int vis2[100] = {0};
    encontrarCaminhos(g, 0, 3, caminho, 0, vis2);

    printf("\nIntersecções entre A e O:\n");
    intersecoesFreq(g, 'A', 'O');

    return 0;
}
