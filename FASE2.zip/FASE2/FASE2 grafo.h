// grafo.h
#ifndef GRAFO_H
#define GRAFO_H

typedef struct Aresta {
    int destino;
    struct Aresta* prox;
} Aresta;

typedef struct Antena {
    char freq;
    int x, y;
} Antena;

typedef struct Vertice {
    Antena info;
    Aresta* adj;
} Vertice;

typedef struct Grafo {
    int numVertices;
    Vertice* vertices;
} Grafo;

// Funções
Grafo* criarGrafo(int capacidade);
void adicionarVertice(Grafo* g, char freq, int x, int y);
void adicionarAresta(Grafo* g, int origem, int destino);
void ligarVertices(Grafo* g);
Grafo* lerGrafoDeFicheiro(const char* nome);

void dfs(Grafo* g, int inicio, int* visitado);
void bfs(Grafo* g, int inicio);
void encontrarCaminhos(Grafo* g, int origem, int destino, int* caminho, int tam, int* visitado);
void intersecoesFreq(Grafo* g, char f1, char f2);

#endif
