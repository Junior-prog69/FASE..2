// grafo.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "grafo.h"

Grafo* criarGrafo(int capacidade) {
    Grafo* g = malloc(sizeof(Grafo));
    g->numVertices = 0;
    g->vertices = malloc(sizeof(Vertice) * capacidade);
    return g;
}

void adicionarVertice(Grafo* g, char freq, int x, int y) {
    g->vertices[g->numVertices].info.freq = freq;
    g->vertices[g->numVertices].info.x = x;
    g->vertices[g->numVertices].info.y = y;
    g->vertices[g->numVertices].adj = NULL;
    g->numVertices++;
}

void adicionarAresta(Grafo* g, int origem, int destino) {
    Aresta* nova = malloc(sizeof(Aresta));
    nova->destino = destino;
    nova->prox = g->vertices[origem].adj;
    g->vertices[origem].adj = nova;
}

void ligarVertices(Grafo* g) {
    for (int i = 0; i < g->numVertices; i++) {
        for (int j = i + 1; j < g->numVertices; j++) {
            if (g->vertices[i].info.freq == g->vertices[j].info.freq) {
                adicionarAresta(g, i, j);
                adicionarAresta(g, j, i);
            }
        }
    }
}

Grafo* lerGrafoDeFicheiro(const char* nome) {
    FILE* f = fopen(nome, "r");
    if (!f) return NULL;

    char linha[128];
    fgets(linha, 128, f); // ignora número de antenas
    Grafo* g = criarGrafo(100);

    int y = 0;
    while (fgets(linha, 128, f)) {
        int len = strlen(linha);
        if (linha[len - 1] == '\n') linha[len - 1] = '\0';

        for (int x = 0; x < len; x++) {
            if (isalnum(linha[x]))
                adicionarVertice(g, linha[x], x, y);
        }
        y++;
    }

    fclose(f);
    ligarVertices(g);
    return g;
}

void dfs(Grafo* g, int inicio, int* visitado) {
    visitado[inicio] = 1;
    printf("(%d,%d)\n", g->vertices[inicio].info.x, g->vertices[inicio].info.y);
    for (Aresta* a = g->vertices[inicio].adj; a; a = a->prox)
        if (!visitado[a->destino])
            dfs(g, a->destino, visitado);
}

void bfs(Grafo* g, int inicio) {
    int vis[100] = {0}, fila[100], front = 0, rear = 0;
    fila[rear++] = inicio;
    vis[inicio] = 1;

    while (front < rear) {
        int atual = fila[front++];
        printf("(%d,%d)\n", g->vertices[atual].info.x, g->vertices[atual].info.y);
        for (Aresta* a = g->vertices[atual].adj; a; a = a->prox) {
            if (!vis[a->destino]) {
                fila[rear++] = a->destino;
                vis[a->destino] = 1;
            }
        }
    }
}

void printCaminho(int* caminho, int tam, Grafo* g) {
    for (int i = 0; i < tam; i++) {
        int idx = caminho[i];
        printf("(%d,%d)", g->vertices[idx].info.x, g->vertices[idx].info.y);
        if (i < tam - 1) printf(" -> ");
    }
    printf("\n");
}

void encontrarCaminhos(Grafo* g, int origem, int destino, int* caminho, int tam, int* visitado) {
    visitado[origem] = 1;
    caminho[tam++] = origem;

    if (origem == destino)
        printCaminho(caminho, tam, g);
    else
        for (Aresta* a = g->vertices[origem].adj; a; a = a->prox)
            if (!visitado[a->destino])
                encontrarCaminhos(g, a->destino, destino, caminho, tam, visitado);

    visitado[origem] = 0; // backtrack
}

void intersecoesFreq(Grafo* g, char f1, char f2) {
    for (int i = 0; i < g->numVertices; i++) {
        for (int j = i + 1; j < g->numVertices; j++) {
            char fi = g->vertices[i].info.freq;
            char fj = g->vertices[j].info.freq;
            if ((fi == f1 && fj == f2) || (fi == f2 && fj == f1))
                printf("(%d,%d) <-> (%d,%d)\n",
                    g->vertices[i].info.x, g->vertices[i].info.y,
                    g->vertices[j].info.x, g->vertices[j].info.y);
        }
    }
}
